MyMacFinder personal Mac installer

Use this package only on your own Macs.

1. Double-click "Install MyMacFinder.command".
2. If macOS blocks the installer script, right-click it and choose Open.
3. The installer removes the download quarantine, signs the app locally, copies it to /Applications, and opens it.
4. If macOS asks for file permissions, allow them in System Settings.

This personal package is not for public distribution. Public macOS distribution requires Developer ID signing and notarization.
