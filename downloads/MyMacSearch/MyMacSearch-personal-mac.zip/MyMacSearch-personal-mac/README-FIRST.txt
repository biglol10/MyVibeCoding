MyMacSearch personal Mac installer

1. Keep MyMacSearch.app and Install MyMacSearch.command in the same folder.
2. Right-click Install MyMacSearch.command and choose Open.
3. Choose indexing locations in the first-run screen before scanning.

This package is ad-hoc signed for personal use. It is not notarized for public distribution.
