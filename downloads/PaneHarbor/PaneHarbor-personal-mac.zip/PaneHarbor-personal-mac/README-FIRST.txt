PaneHarbor personal Mac installer

Use this package only on your own Macs.

1. Double-click "Install PaneHarbor.command".
2. If macOS blocks the installer script, right-click it and choose Open.
3. The installer removes download quarantine, checks the existing ad-hoc signature, copies the app to /Applications, and opens it. An existing PaneHarbor.app is backed up next to it.
4. If macOS asks for file permissions, allow them in System Settings.

This is a local beta package for Macs you control, not a notarized production release. General macOS distribution requires Developer ID signing and notarization.
