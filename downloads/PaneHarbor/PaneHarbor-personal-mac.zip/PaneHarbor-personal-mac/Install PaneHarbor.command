#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SOURCE="$SCRIPT_DIR/PaneHarbor.app"
DEFAULT_INSTALL_DIR="/Applications"
INSTALL_DIR="${PANEHARBOR_INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"
APP_DEST="$INSTALL_DIR/PaneHarbor.app"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

pause_if_interactive() {
  if [[ -t 0 ]]; then
    read -r -p "$1"
  fi
}

if [[ ! -d "$APP_SOURCE" ]]; then
  echo "PaneHarbor.app was not found next to this installer."
  echo "Keep Install PaneHarbor.command and PaneHarbor.app in the same folder."
  pause_if_interactive "Press Return to close."
  exit 1
fi

echo "Installing PaneHarbor for this Mac..."
if pgrep -x PaneHarbor >/dev/null 2>&1; then
  echo "Quit PaneHarbor (including PaneHarbor Preview) before installing, then run this installer again." >&2
  pause_if_interactive "Press Return to close."
  exit 1
fi

echo "Removing quarantine..."
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
xattr -cr "$APP_SOURCE" 2>/dev/null || true

echo "Checking the packaged app signature..."
codesign --verify --deep --strict "$APP_SOURCE"

echo "Copying to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR" 2>/dev/null || true
if [[ -w "$INSTALL_DIR" ]]; then
  if [[ -e "$APP_DEST" ]]; then
    mv "$APP_DEST" "$INSTALL_DIR/PaneHarbor.previous-$(date +%Y%m%d-%H%M%S).saved-bundle"
  fi
  ditto "$APP_SOURCE" "$APP_DEST"
else
  if [[ -e "$APP_DEST" ]]; then
    sudo mv "$APP_DEST" "$INSTALL_DIR/PaneHarbor.previous-$(date +%Y%m%d-%H%M%S).saved-bundle"
  fi
  sudo ditto "$APP_SOURCE" "$APP_DEST"
fi
xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true

if [[ -x "$LSREGISTER" ]]; then
  "$LSREGISTER" -f "$APP_DEST" >/dev/null 2>&1 || true
fi

echo
echo "Installed: $APP_DEST"
echo "Opening PaneHarbor..."
open "$APP_DEST"
echo
echo "If macOS asks for file permissions, enable PaneHarbor in:"
echo "System Settings > Privacy & Security > Files and Folders"
echo "System Settings > Privacy & Security > Full Disk Access"
pause_if_interactive "Press Return to close this installer."
