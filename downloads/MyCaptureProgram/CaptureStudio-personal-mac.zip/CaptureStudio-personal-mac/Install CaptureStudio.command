#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SOURCE="$SCRIPT_DIR/CaptureStudio.app"
DEFAULT_INSTALL_DIR="/Applications"
INSTALL_DIR="${CAPTURE_STUDIO_INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"
APP_DEST="$INSTALL_DIR/CaptureStudio.app"
# Default destination: /Applications/CaptureStudio.app
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

pause_if_interactive() {
  if [[ -t 0 ]]; then
    read -r -p "$1"
  fi
}

if [[ ! -d "$APP_SOURCE" ]]; then
  echo "CaptureStudio.app was not found next to this installer."
  echo "Keep Install CaptureStudio.command and CaptureStudio.app in the same folder."
  pause_if_interactive "Press Return to close."
  exit 1
fi

echo "Installing CaptureStudio for this Mac..."
osascript -e 'tell application "CaptureStudio" to quit' >/dev/null 2>&1 || true
pkill -x CaptureStudio >/dev/null 2>&1 || true

echo "Removing download quarantine from the package..."
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
xattr -cr "$APP_SOURCE" 2>/dev/null || true

echo "Signing locally for this Mac..."
codesign --force --deep --sign - "$APP_SOURCE" >/dev/null
codesign --verify --deep --strict "$APP_SOURCE"

echo "Copying to $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR" 2>/dev/null || true
if [[ -w "$INSTALL_DIR" ]]; then
  rm -rf "$APP_DEST"
  ditto "$APP_SOURCE" "$APP_DEST"
  xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
else
  sudo rm -rf "$APP_DEST"
  sudo ditto "$APP_SOURCE" "$APP_DEST"
  sudo xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
fi

if [[ -x "$LSREGISTER" ]]; then
  "$LSREGISTER" -f "$APP_DEST" >/dev/null 2>&1 || true
fi

echo
echo "Installed: $APP_DEST"
echo "Opening CaptureStudio..."
open "$APP_DEST"
echo
echo "If macOS asks for permissions, enable CaptureStudio in:"
echo "System Settings > Privacy & Security > Screen & System Audio Recording"
echo
pause_if_interactive "Press Return to close this installer."
