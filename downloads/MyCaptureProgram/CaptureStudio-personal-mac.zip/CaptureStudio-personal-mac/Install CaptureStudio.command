#!/usr/bin/env bash
set -euo pipefail
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SOURCE="$SCRIPT_DIR/CaptureStudio.app"
APP_DEST="/Applications/CaptureStudio.app"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

if [[ ! -d "$APP_SOURCE" ]]; then
  echo "CaptureStudio.app was not found next to this installer."
  echo "Keep Install CaptureStudio.command and CaptureStudio.app in the same folder."
  read -r -p "Press Return to close."
  exit 1
fi

echo "Installing CaptureStudio for this Mac..."
osascript -e 'tell application "CaptureStudio" to quit' >/dev/null 2>&1 || true
pkill -x CaptureStudio >/dev/null 2>&1 || true

echo "Removing download quarantine from the package..."
xattr -dr com.apple.quarantine "$SCRIPT_DIR" 2>/dev/null || true
xattr -cr "$APP_SOURCE" 2>/dev/null || true

echo "Signing locally for this Mac..."
codesign --force --deep --sign - "$APP_SOURCE" >/dev/null
codesign --verify --deep --strict "$APP_SOURCE"

echo "Copying to /Applications..."
if [[ -w "/Applications" ]]; then
  rm -rf "$APP_DEST"
  ditto "$APP_SOURCE" "$APP_DEST"
  xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
else
  sudo rm -rf "$APP_DEST"
  sudo ditto "$APP_SOURCE" "$APP_DEST"
  sudo xattr -dr com.apple.quarantine "$APP_DEST" 2>/dev/null || true
fi

if [[ -x "$LSREGISTER" ]]; then
  "$LSREGISTER" -f "$APP_DEST" >/dev/null 2>&1 || true
fi

echo
echo "Installed: $APP_DEST"
echo "Opening CaptureStudio..."
open "$APP_DEST"
echo
echo "If macOS asks for permissions, enable CaptureStudio in:"
echo "System Settings > Privacy & Security > Screen & System Audio Recording"
echo
read -r -p "Press Return to close this installer."
