import{c as r,s as e}from"./flowDiagram-HODETNUW-CFcppOxN.js";import{_ as a}from"./mermaid.core-Beg5RUu4.js";import"./chunk-5VM5RSS4-DgbToeBG.js";import"./chunk-XXDRQBXY-BUFL5uug.js";import"./chunk-POPQ4Y6H-BCBvXTG2.js";import"./chunk-F27PBJKO-BH4xQ7h2.js";import"./channel-BTykJidF.js";import"./index-DghnX4YA.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
