import{c as r,s as e}from"./flowDiagram-HODETNUW-DUhv5S6x.js";import{_ as a}from"./mermaid.core-CH2zT5Be.js";import"./chunk-5VM5RSS4-B8u_JOt6.js";import"./chunk-XXDRQBXY-BeFoP0D2.js";import"./chunk-POPQ4Y6H-BZpxRIef.js";import"./chunk-F27PBJKO-88E-ml8O.js";import"./channel-BJp7jnuS.js";import"./index-DX2PP4u1.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
