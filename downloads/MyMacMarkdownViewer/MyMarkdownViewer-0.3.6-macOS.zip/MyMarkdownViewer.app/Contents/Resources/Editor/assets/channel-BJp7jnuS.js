import{U as a,C as n}from"./mermaid.core-CH2zT5Be.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
