import{c as r,s as e}from"./flowDiagram-HODETNUW-DZh5T3m1.js";import{_ as a}from"./mermaid.core-7ZgEIzKi.js";import"./chunk-5VM5RSS4-c-6vAToR.js";import"./chunk-XXDRQBXY-PG6O94mO.js";import"./chunk-POPQ4Y6H-C7laV-4K.js";import"./chunk-F27PBJKO-B4KSWevV.js";import"./channel-ixJS7EL3.js";import"./index--42YzUQJ.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
