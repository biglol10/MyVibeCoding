import{c as r,s as e}from"./flowDiagram-HODETNUW-CrP53VuH.js";import{_ as a}from"./mermaid.core-B0iNu7Vi.js";import"./chunk-5VM5RSS4-CBFRnLny.js";import"./chunk-XXDRQBXY-CacbvCQo.js";import"./chunk-POPQ4Y6H-CI1BTM7F.js";import"./chunk-F27PBJKO-J3s3kCRz.js";import"./channel-DS4LvnWI.js";import"./index-0DPOfhHe.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
