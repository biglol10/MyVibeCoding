import{c as r,s as e}from"./flowDiagram-HODETNUW-DGQcfdT4.js";import{_ as a}from"./mermaid.core-CXC8FPFb.js";import"./chunk-5VM5RSS4-BsZNaVBR.js";import"./chunk-XXDRQBXY-BwaNDl0A.js";import"./chunk-POPQ4Y6H-CrFw6kms.js";import"./chunk-F27PBJKO-2GU8ffv6.js";import"./channel-D5OIMV-x.js";import"./index-c0KeEW4U.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
