import{c as r,s as e}from"./flowDiagram-HODETNUW-CdxC2_kX.js";import{_ as a}from"./mermaid.core-DszD7c0e.js";import"./chunk-5VM5RSS4-MJxSn8Z4.js";import"./chunk-XXDRQBXY-dWXXCVUY.js";import"./chunk-POPQ4Y6H-C8zyqdis.js";import"./chunk-F27PBJKO-DA0JP9bH.js";import"./channel-Gg2dr76K.js";import"./index-DjjkNem7.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,n=r({defaultLayout:"swimlane",styles:s});export{n as diagram};
