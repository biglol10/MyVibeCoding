FlowPilot Swift Native macOS beta

This package contains the SwiftUI native macOS version of FlowPilot.

Current status:
- Reads the existing FlowPilot database.
- Collects macOS foreground app/window activity natively.
- Receives Chrome/Edge browser extension events on 127.0.0.1:17321.
- Enriches browser sessions by tab domain.
- Reads the active Safari tab URL through macOS automation when Safari is frontmost, then stores the canonical domain.
- Shows native SwiftUI Today, Timeline, Weekly Report, Uncategorized Review, and Rules screens.
- Adds a macOS menu bar item with today's quick summary.

Known beta gaps:
- This build is unsigned and intended for personal local testing.
- Developer ID signing and notarization are still separate release steps.

Install:
1. Run install-flowpilot-native.command.
2. If macOS blocks opening the app, run:
   xattr -dr com.apple.quarantine /Applications/FlowPilot.app
3. Open FlowPilot from Applications.

Permissions:
- Allow Accessibility for accurate app/window metadata.
- Allow Screen Recording if macOS requires it for visible window titles.
- Allow Automation if macOS asks whether FlowPilot may control Safari. This is used only to read Safari's active tab URL/title.
- FlowPilot does not save screen images.
