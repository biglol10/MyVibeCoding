FlowPilot 개인 Mac 설치 안내

이 패키지는 본인 소유의 다른 Mac에 설치하기 위한 개인용 패키지입니다.
Apple Developer ID 공증 배포 파일이 아니므로 FlowPilot.app을 바로 더블클릭하지 마세요.

설치 방법:

1. ZIP 압축을 풉니다.
2. 터미널을 열고 압축을 푼 폴더로 이동합니다.
3. 아래 명령을 실행합니다.

   chmod +x install-flowpilot-personal.command
   ./install-flowpilot-personal.command

직접 Applications로 드래그할 필요는 없습니다.
설치 스크립트는 기존 /Applications/FlowPilot.app을 삭제하고 새 앱을 복사한 뒤
macOS 다운로드 quarantine 속성을 제거합니다.
만약 /Applications에 쓰기 권한이 없으면 설치 중 관리자 비밀번호를 한 번 물어볼 수 있습니다.

macOS 권한 안내:

권한은 install-flowpilot-personal.command나 Terminal이 아니라 /Applications/FlowPilot.app에 줘야 합니다.
설치 스크립트는 마지막에 open /Applications/FlowPilot.app으로 앱 번들을 실행하므로
시스템 설정 > 개인정보 보호 및 보안에서 FlowPilot 또는 /Applications/FlowPilot.app을 선택하면 됩니다.
앱 내부 실행 파일(Contents/MacOS/flowpilot)을 직접 실행하지 마세요.

Chrome 도메인 집계를 쓰려면 Chrome_Extension 폴더를 Chrome 확장 프로그램 개발자 모드에서 로드하세요.